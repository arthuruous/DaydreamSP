extends CharacterBody2D
@onready var terget = $"../player"

var speed = 250.0

func _physics_process(delta:):
	# Add the gravity.
	var direction = (terget.position-position).normalized()
	velocity=direction * speed
	look_at(terget.position)
	move_and_slide()
