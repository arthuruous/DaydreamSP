extends CharacterBody2D

class_name Enemy 
const speed = 10
var is_enemy_chase: bool

var health= 80
var health_max= 80
var health_min= 0 

var dead: bool = false
var taking_damage: bool = false
var damage_to_deal= 20 
var is_dealing_damage: bool = false

var dir: Vector2
const gravity = 900
const knockback_force = 200
var is_roaming: bool = true

func _process(delta):
	if !is_on_floor(): 
		velocity.y += gravity * delta
		velocity.x = 0
	move(delta)
	handle_animation()
	move_and_slide()
	
	
	
func move(delta):
	if !dead:
		if !is_enemy_chase:
			velocity += dir * speed * delta
		is_roaming = true 
	elif dead: velocity.x = 0 
	
func handle_animation(): 
	var anim_sprite = $AnimatedSprite2D
	if !dead and !taking_damage and !is_dealing_damage: 
		anim_sprite.play("running")
		if dir.x == -1: 
			anim_sprite.flip_h = true
		elif dir.x == 1:
			anim_sprite.flip_h = false 
	
